function scrollToBottom() {
  var chatMessages = document.getElementById("chat-messages");
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Call scrollToBottom() whenever a new message is added
document
  .getElementById("sendMessageForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    var userInput = document.getElementById("messageInput").value;
    document.getElementById("messageInput").value = "";
    
    
    var chatMessages = document.getElementById("chat-messages");
        chatMessages.innerHTML +=
          '<div class="chat-message user-message"><div class="message">' +
          userInput +
          '</div><img src="static/images/user-icon.png" class="avatar"></div>';

          var botMessageHtml = `
          <div class="chat-message bot-message" id="bm">
              <img src="static/images/bot-icon.png" class="avatar bot-avatar spin">
              <div class="message"></div>
          </div>
      `;
      chatMessages.innerHTML += botMessageHtml;
  
    fetch("/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message: userInput }),
    })
      .then((response) => response.json())
      .then((data) => {

        var element = document.getElementById('bm'); // will return element
  element.parentNode.removeChild(element); // will remove the element from DOM

        

        
        addBotMessage(data.response);
        chatMessages.scrollTop = chatMessages.scrollHeight;
      });
  });
  function addBotMessage(message) {
    var chatMessages = document.getElementById('chat-messages');
    var botMessageHtml = `
        <div class="chat-message bot-message">
            <img src="static/images/bot-icon.png" class="avatar bot-avatar">
            <div class="message">${message}</div>
        </div>
    `;
    chatMessages.innerHTML += botMessageHtml;

   
    // Scroll to the bottom of the chatbox
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

 window.onload = function() {
        if (performance.getEntriesByType('navigation')[0].type == 'reload') {
            console.log('Page reloaded!');
            // Send a request to the Flask route to clear the session
            // fetch('/clear_session').then(response => response.text()).then(data => console.log(data));
        }
    };





    // ###########################################


   