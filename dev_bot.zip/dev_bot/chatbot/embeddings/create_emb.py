import os
import pickle
import hashlib
import tiktoken
encoding = tiktoken.get_encoding("cl100k_base")
from chatbot.utilities import splitter,loader,llm_model,emb_model
from langchain.vectorstores import FAISS
def num_tokens(docs):
    tokens = 0
    for doc in docs:
        t = len(encoding.encode(docs[0].page_content))
        tokens += t
    return tokens


def calc_embeddings(file_path):
    #define os independent path for faiss index
    #define os independent path for faiss index individual
    db_path = os.path.join("static", "vectorstores", "faiss_index")
    db_path_individual = os.path.join("static", "vectorstores", "faiss_index_individual")
    if os.path.exists(db_path):
        db = FAISS.load_local(db_path, emb_model())
        
        text_splitter = splitter()
        load = loader(file_path)
        docs = load.load_and_split(text_splitter)
        total_tokens = num_tokens(docs)
        cost=total_tokens/1000 * 0.000151
        db_new = FAISS.from_documents(documents=docs, embedding=emb_model())
        if not os.path.exists(db_path_individual):
            os.makedirs(db_path_individual)
        db_new.save_local(os.path.join(db_path_individual,file_path.split('/')[-1]))
        db.merge_from(db_new)
        db.save_local(db_path)
    else:
        text_splitter = splitter()
        
        load = loader(file_path)
        docs = load.load_and_split(text_splitter)
        total_tokens = num_tokens(docs)
        cost=total_tokens/1000 * 0.000151
        db = FAISS.from_documents(documents=docs, embedding=emb_model())
        db.save_local(db_path)
        db.save_local(os.path.join(db_path_individual,file_path.split('/')[-1]))
    return(cost,total_tokens)


def create_emb(file_path):
    #define os independent path for hash file
    pkl_path = os.path.join("static", "hashes.pkl")
    if os.path.exists(pkl_path):
        with open(pkl_path, 'rb') as f:
            existing_hashes = pickle.load(f)
    else:   
        existing_hashes = set()


    def hash_file(file_path):
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as file:
            while chunk := file.read(8192):
                hasher.update(chunk)
        return hasher.hexdigest()

    def is_duplicate(content):
        content_hash = hash_file(content)
        if content_hash in existing_hashes:
            # db = FAISS.load_local(db_path, emb_model())
            return (0,0)
        else:
            existing_hashes.add(content_hash)
            return calc_embeddings(file_path)
            # return False

    hash_file(file_path)
    x=is_duplicate(file_path)
    with open(pkl_path, 'wb') as f:
        pickle.dump(existing_hashes, f)
    return(x)


