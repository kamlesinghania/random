from chatbot.utilities import data_json
from langchain.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
import os
from dotenv import dotenv_values
OPENAI_API_KEY=dotenv_values(".env")["key"]

data = data_json()
def simple_emb(file_name,mode):
    if mode == '1':
        embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
        loader = TextLoader(file_name, encoding = 'UTF-8')
        text_splitter = RecursiveCharacterTextSplitter(
                    chunk_size=500,
                    chunk_overlap=100,
                    separators=["\n\n", "#", "\.", "!", "\?", "\n", ",", " ", ""],
                )
        docs = loader.load_and_split(text_splitter)
        db = FAISS.from_documents(documents=docs, embedding=embeddings)
        return db
    else:
        pass
