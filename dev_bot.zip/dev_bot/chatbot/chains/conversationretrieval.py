
from langchain.chains import ConversationalRetrievalChain

from langchain.vectorstores import FAISS
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
import os
from chatbot.embeddings import create_emb
from chatbot.utilities import llm_model, emb_model, splitter, loader
from langchain.vectorstores import FAISS

class ConversationRetrieval:
    def __init__(self,file_name=''):
        self.llm = llm_model()
        if file_name:
            self.loader = loader(file_name)
            self.text_file = file_name
            self.embeddings = emb_model()
            self.text_splitter = splitter()
            self.docs = self.loader.load_and_split(self.text_splitter)
            self.db = FAISS.from_documents(documents=self.docs, embedding=self.embeddings)
        else:
            self.db_path=db_path = os.path.join("static", "vectorstores", "faiss_index")
            if os.path.exists(db_path):
                self.db = FAISS.load_local(db_path, emb_model())
            else:
                self.db = None
            

        self.conversational_memory = ConversationBufferWindowMemory(
            memory_key='chat_history',
            k=5,
            return_messages=True
        )
        self.ch = ConversationalRetrievalChain.from_llm(
            llm=self.llm,
            retriever=self.db.as_retriever(),
            memory=self.conversational_memory,
            verbose=True
        )
    
            


    def retrieve_conversation(self):
        return self.ch
    
    def citations(self, user_message):
        citations= self.db.similarity_search(user_message, k=4)
        return citations


