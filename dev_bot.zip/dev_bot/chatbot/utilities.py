import os
import json
from dotenv import dotenv_values
from langchain.chat_models import ChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import AzureOpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import WebBaseLoader
from langchain.document_loaders import TextLoader
from langchain.document_loaders import PyPDFLoader

def data_json():
    file_name = 'data.json'
    with open(file_name, 'r') as file:
        data = json.load(file)
        file.close()
    return data



def llm_model():
    data = data_json()
    api_key = dotenv_values('.env')['key']
    model = data['model_llm']
    llm = ChatOpenAI(api_key=api_key, model=model, temperature=0)
    return llm

def emb_model():
    data=data_json()
    api_key = dotenv_values('.env')['key']
    model = data['model_embedding']
    emb = OpenAIEmbeddings(openai_api_key=api_key, model=model)
    return emb
#define code for llm and embedding model for azure or openai

#make a final chain here
def splitter():
    s=RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=100,
            separators=["\n\n", "#", "\.", "!", "\?", "\n", ",", " ", ""],
        )
    return s

def loader(file_name):
    if file_name:
        if os.path.exists(file_name):
            if file_name.endswith('.pdf'):
                loader = PyPDFLoader(file_name)
            else:
                loader = TextLoader(file_name, encoding='UTF-8')
        else:
            loader = WebBaseLoader(file_name)
        return loader
    else:
        pass
