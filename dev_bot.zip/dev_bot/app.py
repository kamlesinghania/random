from flask import Flask, render_template, request, redirect, url_for,session, jsonify
from flask_bootstrap import Bootstrap4
import uuid
import json
import os
import asyncio
from urllib.parse import urlparse
from chatbot.chains.conversationretrieval import ConversationRetrieval
from chatbot.embeddings.create_emb import create_emb
import time
import shutil

from langchain.callbacks import get_openai_callback


app = Flask(__name__)
app.secret_key = '123456'

bootstrap = Bootstrap4(app)
app.config['UPLOAD_FOLDER']=os.path.join('static','uploads')
app.config['Upload_base']=os.path.join('static','knowledge_base')
c={}

@app.before_request
def session_manage():
    if 'id' not in session:
        session['id']=str(uuid.uuid4())[1:5]
        c[session['id']]={}

        print('not there')

@app.route('/test')
def test():
    #time sleep for 20 seconds
    return render_template('test.html',t='double')
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat_knowledge')
def chat_knowledge():
    return render_template('chat_knowledge.html',alert=request.args.get('alert'))

@app.route('/chat', methods=['POST'])
async def chat():
    user_message = request.json['message']
    ch=c[session['id']]['chain']
    print("here")
    #print time for the code below to run
    start=time.time()
    with get_openai_callback() as cb:
        a = ch.run(user_message)
    # print(a)
    end=time.time()
    #save cb,timestamp and timetaken in a log.txt file
    with open('log.txt', 'a') as f:
        f.write(f"Time: {time.strftime('%Y-%m-%d %H:%M:%S')}\nCallback: {cb}\nTime Taken: {end-start}\n\n")

    # citations=c[session['id']]['citation'](user_message)
    
    print("Time Taken:",end-start)
    
    return jsonify({'response': a})

@app.route('/params', methods=['GET', 'POST'])
def params():
    if request.method == 'POST':
        form_data = request.form.to_dict()

        with open('data.json', 'r') as file:
            data = json.load(file)
            for key, value in form_data.items():
                if key in data:
                    if value.lower() == 'true':
                        data[key] = True
                    elif value.lower() == 'false':
                        data[key] = False
                    else:
                        data[key] = value

        with open('data.json', 'w') as file:
            json.dump(data, file, indent=4)

        return redirect(url_for('params'))

    with open('data.json', 'r') as file:
        data = json.load(file)

    return render_template('params.html', data=data)

@app.route('/clear_session')
def clear_session():
    if id in session:
        c.pop(session['id'])
    session.clear()  # Clear all data in the session
    return "Session cleared"

@app.route('/nuke_app')
def nuke_app():
    session.clear()  # Clear all data in the session
    c={}
    #delete all files in uploads folder
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        os.remove(file_path)
    return redirect(url_for('index'))

@app.route('/upload/<t>', methods=['GET', 'POST'])
def upload(t):
    if request.method == 'GET':
        if t=='full':
            return render_template('uploads.html',t=t)
        else:
            return render_template('uploads.html',t='single')
    if request.method == 'POST':
        if t=='full':
            url = request.form.get('webLink', '')
            if url != '':
                #validate web url using urlparse
                parsed_url = urlparse(url)
                if parsed_url.scheme != '' and parsed_url.netloc != '':
                    c[session['id']]['chain']= ConversationRetrieval(url).retrieve_conversation()
                    alert="Website loaded successfully! you can start chatting now"
                    return redirect(url_for('chat_knowledge',alert=alert))

                else:
                    alert="Enter a valid url"
                    return render_template('uploads.html',alert=alert)
            if 'fileUpload' in request.files:
                file = request.files['fileUpload']
                
                if file.filename != '':
                    # Validate file type and process as needed
                    
                    ext=file.filename.split('.')[1]
                    if ext in ['pdf','txt']:
                        file_path = os.path.join(app.config['Upload_base'], file.filename)
                        print(c)
                        file.save(file_path)
                        cost,total_tokens=create_emb(file_path)
                        print(cost,total_tokens)
                        alert="File uploaded successfully! you can start chatting now"
                        return redirect(url_for('chat_knowledge',alert=alert))
                    else:
                        alert="Select only pdf or txt file"
                        return render_template('uploads.html',alert=alert,t=t)
                        
                else:
                    alert="Select a file"
                    return render_template('uploads.html',alert=alert,t=t)    
        ########################
        else:
            url = request.form.get('webLink', '')
            if url != '':
                #validate web url using urlparse
                parsed_url = urlparse(url)
                if parsed_url.scheme != '' and parsed_url.netloc != '':
                    c[session['id']]['chain']= ConversationRetrieval(url).retrieve_conversation()
                    alert="Website loaded successfully! you can start chatting now"
                    return redirect(url_for('chat_knowledge',alert=alert))

                else:
                    alert="Enter a valid url"
                    return render_template('uploads.html',alert=alert)
            if 'fileUpload' in request.files:
                file = request.files['fileUpload']
                
                if file.filename != '':
                    # Validate file type and process as needed
                    
                    ext=file.filename.split('.')[1]
                    if ext in ['pdf','txt']:
                        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                        print(c)
                        file.save(file_path)
                        c[session['id']]['obj']=ConversationRetrieval(file_path)
                        c[session['id']]['chain']= c[session['id']]['obj'].retrieve_conversation()
                        c[session['id']]['citation']=c[session['id']]['obj'].citations
                        alert="File uploaded successfully! you can start chatting now"
                        return redirect(url_for('chat_knowledge',alert=alert))
                    else:
                        alert="Select only pdf or txt file"
                        return render_template('uploads.html',alert=alert)
                        
                else:
                    alert="Select a file"
                    return render_template('uploads.html',alert=alert)

@app.route('/destroy_knowledge')
def destroy_knowledge():
    #delete folder vectorstores and all files inside it 
    shutil.rmtree(os.path.join('static','vectorstores'))
    os.remove(os.path.join('static','hashes.pkl'))
    for filename in os.listdir(app.config['Upload_base']):
        file_path = os.path.join(app.config['Upload_base'], filename)
        os.remove(file_path)

    return redirect(url_for('index'))   


    
@app.route('/submit-feedback', methods=['GET', 'POST'])
def submit_feedback():
    if request.method == 'POST':
        feedback = request.form.get('feedback')
        #timestamp in nice format
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S')

        # Save feedback to a text file
        with open('feedback.txt', 'a') as f:
            f.write(f"Time: {timestamp}\nFeedback: {feedback}\n\n")

        alert='Feedback submitted successfully!'
        return render_template('index.html',alert=alert)

    return render_template('feedback.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)