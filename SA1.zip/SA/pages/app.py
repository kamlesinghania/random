import streamlit as st
# Pandas
import pandas as pd



#favicon

# Title 
st.title("Upload excel")
# File uploader allows user to add their own Excel file
uploaded_file = st.file_uploader("Upload an Excel file", type=['xlsx'])

# The app will process the Excel file if it's uploaded
if uploaded_file is not None:
    # Read and load the excel file into a dataframe
    df = pd.read_excel(uploaded_file)

    # Write the dataframe to the app
    st.write("Data from Excel file:")
    st.dataframe(df)

    # Numeric input for row number until which rows should be deleted
    row_number = st.number_input("Enter the row number until which to delete (non-inclusive)", min_value=0, max_value=len(df), value=0, step=1)

    # Column selector
    column_to_display = st.selectbox("Select a column to display", df.columns)

    # Button to confirm deletion and display column
    if st.button('Update Table'):
        # Delete rows up to the specified row number
        df = df.iloc[row_number:]
        if 'transform_dataframe' not in st.session_state:
            st.session_state['transform_dataframe'] = pd.DataFrame()
        st.session_state['transform_dataframe'] = df
        # Reset the index
        df = df.reset_index(drop=True)
        # Display selected column from the updated DataFrame
        
        
        st.dataframe(df[[column_to_display]])
        data=df[[column_to_display]]
    
        if 'my_dataframe' not in st.session_state:
            st.session_state['my_dataframe'] = pd.DataFrame()
        st.session_state['my_dataframe'] = data
        
else:
    st.write("Upload an Excel file to get started.")

