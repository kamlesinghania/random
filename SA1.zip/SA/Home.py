import streamlit as st

# 1. Set Up Your Streamlit App
st.set_page_config(page_title="My Awesome App", layout="wide")

# 2. Add a Hero Image
hero_image = './static/hero.svg'  # Update this to the path of your hero image
st.image(hero_image, use_column_width=True)

# 3. Add a Title and Introduction
st.title("Welcome to My Awesome App")
st.write("""
This app provides powerful tools for data exploration and interaction. 
Feel free to navigate through the app and explore its features.
""")

# 4. List the Features
st.header("Features")
st.subheader("Data Exploration using Agents")
st.write("""
- Interactively explore your data using intelligent agents.
- Gain insights and make informed decisions based on your data analysis.
""")

st.subheader("Chat with your Excel file")
st.write("""
- Upload your Excel files and interact with them through a conversational interface.
- Ask questions, get insights, and perform analysis on your Excel data in a natural way.
""")

# Additional Features (if any)
# ...

# Footer or additional information
st.write("Built with ❤️ using Streamlit")
